# Adaptive Task Management System

A full-stack MVP with React + Vite, Express, MongoDB, JWT authentication, task CRUD, an explainable rule-based adaptive priority engine, and a productivity dashboard.

## Requirements
- Node.js 18+
- MongoDB Atlas account (or local MongoDB)
- Git (optional)

## 1. Configure MongoDB
Create a MongoDB database and copy its connection string. In `backend/.env`, replace the placeholder:

```env
PORT=5000
MONGO_URI=mongodb+srv://USERNAME:PASSWORD@CLUSTER.mongodb.net/adaptive_task_manager?retryWrites=true&w=majority
JWT_SECRET=replace_this_with_a_long_random_secret
CLIENT_URL=http://localhost:5173
```

If using local MongoDB, a typical URI is:
`mongodb://127.0.0.1:27017/adaptive_task_manager`

## 2. Install dependencies
Open two terminals from the project root.

Terminal 1:
```bash
cd backend
npm install
npm run dev
```

Terminal 2:
```bash
cd frontend
npm install
npm run dev
```

Open http://localhost:5173

## Features
- Register and log in
- Create, edit, complete, delete and filter tasks
- Set deadlines, estimates, categories and priorities
- Adaptive priority suggestions based on deadline proximity and postponement count
- Explainable suggestions (the app tells you why priority changed)
- Dashboard with task counts and completion progress
- Automatic reminders 24 hours before a deadline and when the deadline arrives
- In-app notification centre with unread counts and read controls
- Optional desktop/browser notifications (requires browser permission and an open TaskFlow tab)
- Data stored in MongoDB; passwords hashed with bcrypt

## Adaptive engine
The backend calculates an adaptive priority from:
- Base priority
- Deadline proximity
- Number of times a task was postponed

It returns an explanation with each task. This MVP uses transparent rule-based adaptation; it does not claim to train a machine-learning model.

## Notes
- The optional AI/LLM integration is intentionally not wired to a paid API. Add an API key only when you choose a provider.
- Never commit `.env` or API keys.


## Automatic reminders
The backend starts a reminder scheduler after MongoDB connects. It checks every 30 seconds for active tasks whose deadlines are within the next 24 hours, and for tasks that have just reached their deadline. Each reminder is stored in MongoDB and generated only once for a task/deadline/reminder type. The frontend refreshes notifications every 30 seconds and displays them in the bell menu.

To receive Windows/browser pop-up notifications, open TaskFlow in the browser, sign in, open the notification bell, and select **Enable desktop alerts**. Allow notifications when the browser asks. In-app reminders continue to work if desktop permission is denied. Desktop alerts require the browser tab to remain open; reminders are stored by the backend while it is running.

The due-date field currently accepts a calendar date (not a time). TaskFlow treats the selected date as a 9:00 AM deadline in the user’s local browser time, so the 24-hour reminder is scheduled for approximately 9:00 AM on the previous day.
