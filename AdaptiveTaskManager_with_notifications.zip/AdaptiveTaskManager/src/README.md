# Source code
The application source is split into `frontend/` (React/Vite) and `backend/` (Express/Mongoose).
See the root README for setup and run instructions.
