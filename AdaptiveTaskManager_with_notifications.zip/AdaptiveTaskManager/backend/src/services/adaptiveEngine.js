const rank = { Low: 1, Medium: 2, High: 3 };

// Explainable rule-based adaptation: deadline pressure + repeated postponement.
export function adaptTask(task) {
  if (task.completed) return { adaptivePriority: task.priority, reason: 'Task completed.' };
  let score = rank[task.priority] || 2;
  const reasons = [];
  if (task.dueDate) {
    const daysLeft = (new Date(task.dueDate).getTime() - Date.now()) / 86400000;
    if (daysLeft < 0) { score += 2; reasons.push('The deadline has passed.'); }
    else if (daysLeft <= 1) { score += 2; reasons.push('The deadline is within 24 hours.'); }
    else if (daysLeft <= 3) { score += 1; reasons.push('The deadline is within 3 days.'); }
  }
  if ((task.postponedCount || 0) >= 3) {
    score += 1; reasons.push(`It has been postponed ${task.postponedCount} times.`);
  } else if ((task.postponedCount || 0) >= 1) {
    reasons.push(`It has been postponed ${task.postponedCount} time(s).`);
  }
  const adaptivePriority = score >= 3 ? 'High' : score === 2 ? 'Medium' : 'Low';
  return {
    adaptivePriority,
    reason: reasons.length ? reasons.join(' ') : 'No deadline or postponement pressure detected.'
  };
}
