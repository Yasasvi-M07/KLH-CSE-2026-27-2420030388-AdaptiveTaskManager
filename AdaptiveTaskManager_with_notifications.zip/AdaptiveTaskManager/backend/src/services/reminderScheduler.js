import Task from '../models/Task.js';
import Notification from '../models/Notification.js';

const DAY = 24 * 60 * 60 * 1000;
const CHECK_INTERVAL = 30 * 1000;
let timer;
let running = false;

async function createReminder(task, type) {
  const message = type === '24h'
    ? `“${task.title}” is due in 24 hours.`
    : `“${task.title}” is due now.`;

  await Notification.updateOne(
    { task: task._id, type, dueAt: task.dueDate },
    { $setOnInsert: {
      user: task.user,
      task: task._id,
      taskTitle: task.title,
      type,
      dueAt: task.dueDate,
      message,
      read: false,
    } },
    { upsert: true }
  );
}

export async function checkReminders() {
  if (running) return;
  running = true;
  try {
    const now = new Date();
    const in24Hours = new Date(now.getTime() + DAY);
    const upcomingTasks = await Task.find({
      completed: false,
      dueDate: { $gt: now, $lte: in24Hours },
    }).select('_id user title dueDate');

    for (const task of upcomingTasks) await createReminder(task, '24h');

    // The short window prevents an old overdue task from generating a false
    // "due now" alert whenever the server restarts.
    const justDue = new Date(now.getTime() - CHECK_INTERVAL * 2);
    const dueTasks = await Task.find({
      completed: false,
      dueDate: { $gt: justDue, $lte: now },
    }).select('_id user title dueDate');

    for (const task of dueTasks) await createReminder(task, 'due');
  } catch (error) {
    console.error('Reminder scheduler error:', error.message);
  } finally {
    running = false;
  }
}

export function startReminderScheduler() {
  if (timer) return;
  checkReminders();
  timer = setInterval(checkReminders, CHECK_INTERVAL);
  console.log('Task reminder scheduler started (checks every 30 seconds).');
}
