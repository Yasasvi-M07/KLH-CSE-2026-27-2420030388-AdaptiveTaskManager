import Task from '../models/Task.js';
import { adaptTask } from '../services/adaptiveEngine.js';

function present(task) {
  const raw = task.toObject ? task.toObject() : task;
  const adaptive = adaptTask(raw);
  return { ...raw, adaptivePriority: adaptive.adaptivePriority, adaptiveReason: adaptive.reason };
}
export async function listTasks(req, res) {
  try {
    const tasks = await Task.find({ user: req.userId }).sort({ completed: 1, dueDate: 1, createdAt: -1 });
    res.json(tasks.map(present));
  } catch (err) { res.status(500).json({ message: 'Could not load tasks.', error: err.message }); }
}
export async function createTask(req, res) {
  try {
    const { title, description, category, priority, dueDate, estimatedMinutes } = req.body;
    if (!title?.trim()) return res.status(400).json({ message: 'Task title is required.' });
    const task = await Task.create({ user: req.userId, title, description, category, priority, dueDate: dueDate || null, estimatedMinutes });
    res.status(201).json(present(task));
  } catch (err) { res.status(400).json({ message: 'Could not create task.', error: err.message }); }
}
export async function updateTask(req, res) {
  try {
    const allowed = ['title', 'description', 'category', 'priority', 'dueDate', 'estimatedMinutes', 'completed'];
    const updates = Object.fromEntries(Object.entries(req.body).filter(([key]) => allowed.includes(key)));
    const task = await Task.findOneAndUpdate({ _id: req.params.id, user: req.userId }, { $set: updates }, { new: true, runValidators: true });
    if (!task) return res.status(404).json({ message: 'Task not found.' });
    res.json(present(task));
  } catch (err) { res.status(400).json({ message: 'Could not update task.', error: err.message }); }
}
export async function postponeTask(req, res) {
  try {
    const task = await Task.findOneAndUpdate({ _id: req.params.id, user: req.userId }, { $inc: { postponedCount: 1 } }, { new: true });
    if (!task) return res.status(404).json({ message: 'Task not found.' });
    res.json(present(task));
  } catch (err) { res.status(500).json({ message: 'Could not postpone task.' }); }
}
export async function deleteTask(req, res) {
  try {
    const task = await Task.findOneAndDelete({ _id: req.params.id, user: req.userId });
    if (!task) return res.status(404).json({ message: 'Task not found.' });
    res.json({ message: 'Task deleted.' });
  } catch (err) { res.status(500).json({ message: 'Could not delete task.' }); }
}
