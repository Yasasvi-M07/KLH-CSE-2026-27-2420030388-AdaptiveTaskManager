import Notification from '../models/Notification.js';

export async function listNotifications(req, res) {
  try {
    const notifications = await Notification.find({ user: req.userId })
      .sort({ createdAt: -1 })
      .limit(40)
      .lean();
    res.json(notifications);
  } catch (error) {
    res.status(500).json({ message: 'Could not load notifications.', error: error.message });
  }
}

export async function markNotificationRead(req, res) {
  try {
    const notification = await Notification.findOneAndUpdate(
      { _id: req.params.id, user: req.userId },
      { $set: { read: true } },
      { new: true }
    );
    if (!notification) return res.status(404).json({ message: 'Notification not found.' });
    res.json(notification);
  } catch (error) {
    res.status(500).json({ message: 'Could not update notification.', error: error.message });
  }
}

export async function markAllNotificationsRead(req, res) {
  try {
    await Notification.updateMany({ user: req.userId, read: false }, { $set: { read: true } });
    res.json({ message: 'All notifications marked as read.' });
  } catch (error) {
    res.status(500).json({ message: 'Could not update notifications.', error: error.message });
  }
}
