import mongoose from 'mongoose';
const taskSchema = new mongoose.Schema({
  user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true, index: true },
  title: { type: String, required: true, trim: true, maxlength: 140 },
  description: { type: String, default: '' },
  category: { type: String, default: 'General' },
  priority: { type: String, enum: ['Low', 'Medium', 'High'], default: 'Medium' },
  dueDate: { type: Date, default: null },
  estimatedMinutes: { type: Number, default: 30, min: 5 },
  completed: { type: Boolean, default: false },
  postponedCount: { type: Number, default: 0 },
  lastAdaptiveReason: { type: String, default: '' }
}, { timestamps: true });
export default mongoose.model('Task', taskSchema);
