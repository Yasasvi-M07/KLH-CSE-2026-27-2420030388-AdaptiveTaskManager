import mongoose from 'mongoose';

const notificationSchema = new mongoose.Schema({
  user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true, index: true },
  task: { type: mongoose.Schema.Types.ObjectId, ref: 'Task', required: true },
  taskTitle: { type: String, required: true },
  type: { type: String, enum: ['24h', 'due'], required: true },
  dueAt: { type: Date, required: true },
  message: { type: String, required: true },
  read: { type: Boolean, default: false },
}, { timestamps: true });

// A task can generate one reminder of each type for each saved deadline.
notificationSchema.index({ task: 1, type: 1, dueAt: 1 }, { unique: true });
export default mongoose.model('Notification', notificationSchema);
