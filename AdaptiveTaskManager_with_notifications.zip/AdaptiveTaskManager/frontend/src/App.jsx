import { useEffect, useMemo, useRef, useState } from 'react';
import {
  Bell, Check, CheckCircle2, Circle, Clock3, ListTodo, LogOut, Plus,
  Sparkles, Trash2, TrendingUp, CalendarDays, BellRing
} from 'lucide-react';
import api from './api';

const emptyForm = { title: '', description: '', category: 'Study', priority: 'Medium', dueDate: '', estimatedMinutes: 60 };
const dateLabel = (d) => d ? new Date(d).toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' }) : 'No deadline';
const timeLabel = (d) => new Date(d).toLocaleString(undefined, { month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' });

function Auth({ onAuth }) {
  const [mode, setMode] = useState('login');
  const [form, setForm] = useState({ name: '', email: '', password: '' });
  const [error, setError] = useState('');
  const submit = async (e) => {
    e.preventDefault(); setError('');
    try {
      const { data } = await api.post(`/auth/${mode}`, form);
      localStorage.setItem('atm_token', data.token); onAuth(data.user);
    } catch (err) { setError(err.response?.data?.message || 'Unable to connect to the server.'); }
  };
  return <main className="auth-wrap"><div className="auth-card"><div className="brand-mark"><ListTodo size={25}/></div><p className="eyebrow">YOUR PERSONAL PRODUCTIVITY SPACE</p><h1>{mode === 'login' ? 'Welcome back' : 'Create your account'}</h1><p className="muted">A task manager that adapts to the way you work.</p>
    <form onSubmit={submit}>{mode === 'register' && <input placeholder="Your name" required value={form.name} onChange={e=>setForm({...form,name:e.target.value})}/>}<input type="email" placeholder="Email address" required value={form.email} onChange={e=>setForm({...form,email:e.target.value})}/><input type="password" placeholder="Password (min. 6 characters)" minLength="6" required value={form.password} onChange={e=>setForm({...form,password:e.target.value})}/>{error && <p className="error">{error}</p>}<button className="primary full">{mode === 'login' ? 'Sign in' : 'Create account'}</button></form>
    <p className="switch">{mode === 'login' ? "Don't have an account?" : 'Already registered?'} <button className="link" onClick={()=>{setMode(mode==='login'?'register':'login');setError('')}}>{mode==='login'?'Create one':'Sign in'}</button></p>
  </div></main>;
}

function App() {
  const [user, setUser] = useState(null);
  const [tasks, setTasks] = useState([]);
  const [notifications, setNotifications] = useState([]);
  const [filter, setFilter] = useState('All');
  const [form, setForm] = useState(emptyForm);
  const [editing, setEditing] = useState(null);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [notificationOpen, setNotificationOpen] = useState(false);
  const [permission, setPermission] = useState(typeof window !== 'undefined' && 'Notification' in window ? Notification.permission : 'unsupported');
  const notificationBaseline = useRef(false);
  const knownNotificationIds = useRef(new Set());

  const load = async () => { const { data } = await api.get('/tasks'); setTasks(data); };

  const loadNotifications = async () => {
    const { data } = await api.get('/notifications');
    if (notificationBaseline.current) {
      const fresh = data.filter(item => !knownNotificationIds.current.has(item._id));
      if (permission === 'granted' && 'Notification' in window) {
        fresh.forEach(item => new Notification('TaskFlow reminder', {
          body: item.message,
          tag: item._id,
          icon: '/favicon.svg'
        }));
      }
    }
    notificationBaseline.current = true;
    knownNotificationIds.current = new Set(data.map(item => item._id));
    setNotifications(data);
  };

  useEffect(() => {
    if (localStorage.getItem('atm_token')) {
      api.get('/tasks').then(()=>setUser({name:'there'})).catch(()=>localStorage.removeItem('atm_token'));
    }
  }, []);

  useEffect(() => {
    if (!user) return;
    load().catch(e=>setError(e.response?.data?.message || 'Could not load tasks.'));
    loadNotifications().catch(()=>{});
    const interval = window.setInterval(() => {
      loadNotifications().catch(()=>{});
      load().catch(()=>{});
    }, 30000);
    return () => window.clearInterval(interval);
  }, [user, permission]);

  const stats = useMemo(() => ({ total: tasks.length, done: tasks.filter(t=>t.completed).length, open: tasks.filter(t=>!t.completed).length, high: tasks.filter(t=>!t.completed && t.adaptivePriority==='High').length }), [tasks]);
  const visible = tasks.filter(t => filter==='All' ? true : filter==='Active' ? !t.completed : filter==='Completed' ? t.completed : t.adaptivePriority==='High' && !t.completed);
  const unreadCount = notifications.filter(n => !n.read).length;

  const saveTask = async (e) => {
    e.preventDefault(); setError(''); setLoading(true);
    try {
      const payload = { ...form, estimatedMinutes: Number(form.estimatedMinutes), dueDate: form.dueDate ? new Date(`${form.dueDate}T09:00:00`).toISOString() : null };
      if (editing) await api.patch(`/tasks/${editing}`, payload); else await api.post('/tasks', payload);
      setForm(emptyForm); setEditing(null); await load();
    } catch (err) { setError(err.response?.data?.message || 'Could not save task.'); }
    finally { setLoading(false); }
  };
  const editTask = (t) => { setEditing(t._id); setForm({ title:t.title, description:t.description||'', category:t.category||'Study', priority:t.priority, dueDate:t.dueDate?new Date(t.dueDate).toISOString().slice(0,10):'', estimatedMinutes:t.estimatedMinutes||60 }); window.scrollTo({top:0,behavior:'smooth'}); };
  const toggle = async (t) => { await api.patch(`/tasks/${t._id}`, { completed: !t.completed }); await load(); };
  const postpone = async (id) => { await api.post(`/tasks/${id}/postpone`); await load(); };
  const remove = async (id) => { if (confirm('Delete this task?')) { await api.delete(`/tasks/${id}`); await load(); } };
  const markRead = async (id) => {
    try {
      await api.patch(`/notifications/${id}/read`);
      setNotifications(items => items.map(item => item._id === id ? { ...item, read: true } : item));
    } catch { setError('Could not update notification.'); }
  };
  const markAllRead = async () => {
    try {
      await api.patch('/notifications/read-all');
      setNotifications(items => items.map(item => ({ ...item, read: true })));
    } catch { setError('Could not update notifications.'); }
  };
  const enableDesktopAlerts = async () => {
    if (!('Notification' in window)) { setPermission('unsupported'); return; }
    const result = await Notification.requestPermission();
    setPermission(result);
  };
  const logout = () => {
    localStorage.removeItem('atm_token'); setUser(null); setTasks([]); setNotifications([]);
    notificationBaseline.current = false;
    knownNotificationIds.current = new Set();
  };

  if (!user) return <Auth onAuth={setUser}/>;
  return <div className="app-shell"><aside className="sidebar"><div className="brand"><span className="brand-mark"><ListTodo size={23}/></span><span>TaskFlow<small>ADAPTIVE PLANNER</small></span></div><div className="side-label">WORKSPACE</div><button className="nav-item active"><ListTodo size={18}/> My tasks</button><div className="side-note"><Sparkles size={18}/><b>Adaptive insight</b><p>Task priorities adjust as deadlines approach and tasks are postponed.</p></div><button className="logout" onClick={logout}><LogOut size={17}/> Sign out</button></aside>
    <main className="main"><header className="topbar"><div><p className="eyebrow">YOUR PRODUCTIVITY SPACE</p><h1>Good to see you{user.name && user.name!=='there' ? `, ${user.name}` : ''}.</h1><p className="muted">Make progress, one task at a time.</p></div><div className="topbar-actions"><div className="notification-wrap"><button className={`notification-bell ${notificationOpen?'active':''}`} onClick={()=>setNotificationOpen(v=>!v)} aria-label="Open notifications"><Bell size={20}/>{unreadCount>0&&<span className="notification-count">{unreadCount>9?'9+':unreadCount}</span>}</button>
      {notificationOpen&&<div className="notification-popover"><div className="notification-heading"><div><b>Notifications</b><small>{unreadCount} unread</small></div>{unreadCount>0&&<button onClick={markAllRead}>Mark all read</button>}</div>
        {permission==='default'&&<button className="enable-alerts" onClick={enableDesktopAlerts}><BellRing size={15}/> Enable desktop alerts</button>}
        {permission==='denied'&&<p className="permission-note">Desktop alerts are blocked in your browser settings. In-app reminders will still work.</p>}
        {permission==='unsupported'&&<p className="permission-note">This browser does not support desktop notifications.</p>}
        {notifications.length===0?<div className="notification-empty">No reminders yet. We'll alert you 24 hours before a task deadline and again when it is due.</div>:<div className="notification-list">{notifications.map(n=><button key={n._id} className={`notification-item ${n.read?'read':''}`} onClick={()=>!n.read&&markRead(n._id)}><span className={`notification-dot ${n.type==='due'?'due':''}`}></span><span className="notification-copy"><b>{n.taskTitle}</b><span>{n.message}</span><small>{timeLabel(n.createdAt)}</small></span>{!n.read&&<span className="unread-mark"/>}</button>)}</div>}
      </div>}</div><div className="avatar">{(user.name||'U')[0].toUpperCase()}</div></div></header>
      {error && <div className="error-banner">{error}</div>}
      <section className="stats"><div className="stat-card"><span className="stat-icon blue"><ListTodo/></span><div><small>Total tasks</small><strong>{stats.total}</strong></div></div><div className="stat-card"><span className="stat-icon green"><CheckCircle2/></span><div><small>Completed</small><strong>{stats.done}</strong></div></div><div className="stat-card"><span className="stat-icon purple"><TrendingUp/></span><div><small>In progress</small><strong>{stats.open}</strong></div></div><div className="stat-card"><span className="stat-icon orange"><Clock3/></span><div><small>Adaptive high priority</small><strong>{stats.high}</strong></div></div></section>
      <div className="content-grid"><section className="panel form-panel"><div className="panel-heading"><div><p className="eyebrow">{editing?'UPDATE TASK':'PLAN YOUR DAY'}</p><h2>{editing?'Edit task':'Add a task'}</h2></div><span className="heading-icon"><Plus/></span></div>
        <form onSubmit={saveTask} className="task-form"><label>Task title<input placeholder="e.g. Complete ASE project report" required maxLength="140" value={form.title} onChange={e=>setForm({...form,title:e.target.value})}/></label><label>Description<textarea placeholder="Add a few details..." rows="3" value={form.description} onChange={e=>setForm({...form,description:e.target.value})}/></label><div className="form-row"><label>Category<select value={form.category} onChange={e=>setForm({...form,category:e.target.value})}>{['Study','Work','Personal','Project','Other'].map(x=><option key={x}>{x}</option>)}</select></label><label>Priority<select value={form.priority} onChange={e=>setForm({...form,priority:e.target.value})}>{['Low','Medium','High'].map(x=><option key={x}>{x}</option>)}</select></label></div><div className="form-row"><label>Due date<input type="date" value={form.dueDate} onChange={e=>setForm({...form,dueDate:e.target.value})}/></label><label>Estimate (minutes)<input type="number" min="5" step="5" value={form.estimatedMinutes} onChange={e=>setForm({...form,estimatedMinutes:e.target.value})}/></label></div><p className="reminder-hint"><Bell size={13}/> Automatic reminders: 24 hours before the deadline and when it is due.</p><button className="primary full" disabled={loading}>{loading?'Saving...':editing?'Save changes':'＋ Add task'}</button>{editing && <button type="button" className="secondary full" onClick={()=>{setEditing(null);setForm(emptyForm)}}>Cancel editing</button>}</form>
      </section>
      <section className="panel tasks-panel"><div className="panel-heading"><div><p className="eyebrow">YOUR WORKLOAD</p><h2>Tasks <span className="count">{visible.length}</span></h2></div><div className="filter-wrap">{['All','Active','Completed','High priority'].map(f=><button key={f} className={`filter ${filter===f?'selected':''}`} onClick={()=>setFilter(f)}>{f}</button>)}</div></div>
        {visible.length===0 ? <div className="empty"><div className="empty-icon"><CalendarDays/></div><b>No tasks here yet</b><p>Add a task to get your adaptive planner started.</p></div> : <div className="task-list">{visible.map(t=><article className={`task ${t.completed?'is-done':''}`} key={t._id}><button className="check" title="Mark complete" onClick={()=>toggle(t)}>{t.completed?<CheckCircle2/>:<Circle/>}</button><div className="task-body"><div className="task-title-row"><h3>{t.title}</h3><span className={`priority ${String(t.adaptivePriority||t.priority).toLowerCase()}`}>{t.adaptivePriority||t.priority}</span></div>{t.description&&<p className="task-desc">{t.description}</p>}<div className="task-meta"><span>{t.category}</span><span><CalendarDays size={13}/> {dateLabel(t.dueDate)}</span><span><Clock3 size={13}/> {t.estimatedMinutes} min</span></div><div className="adapt-note"><Sparkles size={13}/><span><b>Adaptive insight:</b> {t.adaptiveReason}</span></div><div className="task-actions"><button onClick={()=>editTask(t)}>Edit</button>{!t.completed&&<button onClick={()=>postpone(t._id)}>Postpone +1</button>}<button className="delete" onClick={()=>remove(t._id)}><Trash2 size={13}/> Delete</button></div></div></article>)}</div>}
      </section></div>
      <footer>TaskFlow · Adaptive Task Management System <span>Built with React, Express & MongoDB</span></footer>
    </main></div>;
}
export default App;
