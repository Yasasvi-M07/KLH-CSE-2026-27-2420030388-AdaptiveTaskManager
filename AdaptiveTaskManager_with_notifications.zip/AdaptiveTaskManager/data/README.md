# Data
This MVP uses MongoDB collections (`users` and `tasks`) created by Mongoose at runtime. No external dataset is required.
